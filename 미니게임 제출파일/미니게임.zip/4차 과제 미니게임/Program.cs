﻿using System;

class Program
{
    static void Main()
    {
        GameManager gamemanager = new GameManager();
        gamemanager.Run();
    }
}