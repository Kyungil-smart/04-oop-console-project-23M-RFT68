﻿
public interface IInteractable3
{
    public void Interact(Monster monster);
}