﻿
public interface IInteractable2
{
    public void Interact(Bullet bullet);
}