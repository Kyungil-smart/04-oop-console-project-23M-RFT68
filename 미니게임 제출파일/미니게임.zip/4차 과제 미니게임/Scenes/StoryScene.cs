﻿public class StoryScene : Scene
{
    public override void Enter()
    {
    }

    public override void Update()
    {
    }

    public override void Render()
    {
    }

    public override void Exit()
    {
    }
}